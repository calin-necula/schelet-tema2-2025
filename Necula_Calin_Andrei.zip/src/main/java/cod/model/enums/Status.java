package cod.model.enums;

public enum Status {
    OPEN, IN_PROGRESS, RESOLVED, CLOSED
}
