package cod.model.enums;

public enum Seniority {
    JUNIOR, MID, SENIOR
}
