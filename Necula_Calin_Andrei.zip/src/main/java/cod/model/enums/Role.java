package cod.model.enums;

public enum Role {
    REPORTER, DEVELOPER, MANAGER
}
