package cod.model.enums;

public enum TicketType {
    BUG,
    FEATURE_REQUEST,
    UI_FEEDBACK
}
