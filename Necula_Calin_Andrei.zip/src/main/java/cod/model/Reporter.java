package cod.model;

public class Reporter extends User {
}
